
export type JSONParams = {
    [key: string]: any;
}