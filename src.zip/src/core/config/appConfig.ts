export const appConfig = {
    webPageTitle: "VIVEKA AI",
    webPageDescription: "VIVEKA AI is a platform that provides AI-powered solutions for various industries, including healthcare, finance, and education. Our mission is to leverage the power of artificial intelligence to improve efficiency, accuracy, and decision-making in these sectors.",
};