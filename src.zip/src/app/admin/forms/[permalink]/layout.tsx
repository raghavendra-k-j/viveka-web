"use client";

import { useAdminFormsStore } from "@/ui/features/admin/forms/AdminFormsContext";
import { AdminFormByIdProvider, useAdminFormsByIdStore } from "@/ui/features/admin/forms/byid/AdminFormByIdContext";
import { useParams } from "next/navigation";
import { useEffect } from "react";

export type AdminFormByIdLayoutParams = {
  children: React.ReactNode;
}

type AdminFormByIdURLParams = {
  permalink: string;
}

function AdminFormContent({ children }: { children: React.ReactNode }) {
  const urlParams = useParams<AdminFormByIdURLParams>();

  const formDetailState = useAdminFormsByIdStore((state) => state.formDetailState);
  const getFormDetail = useAdminFormsByIdStore((state) => state.getFormDetail);
  const loadFormDetail = useAdminFormsByIdStore((state) => state.loadFormDetail);

  useEffect(() => {
    loadFormDetail(urlParams.permalink);
  }, [urlParams.permalink]);

  const buildLoader = () => {
    console.debug("Building: Loading state");
    return <div className="flex justify-center items-center h-full">Loading...</div>;
  };

  const buildError = () => {
    console.debug("Building: Error state");
    return (
      <div className="flex justify-center items-center h-full text-red-500">
        Error: {formDetailState.error?.message || "Unknown error"}
      </div>
    );
  };

  const buildSuccess = () => {
    console.debug("Building: Success state");
    const formDetail = getFormDetail();
    return (
      <div className="flex justify-center items-center h-full">
        {formDetail?.title ?? "No Title"}
      </div>
    );
  };

  const buildUnknown = () => {
    console.debug("Building: Unknown state");
    return <div className="flex justify-center items-center h-full">Unknown state</div>;
  };

  const renderContent = () => {
    if (formDetailState.isLoading || formDetailState.isInitial) return buildLoader();
    if (formDetailState.isError) return buildError();
    if (formDetailState.isSuccess) return buildSuccess();
    return buildUnknown();
  };

  return renderContent();
}



export default function AdminFormByIdLayoutPage(params: AdminFormByIdLayoutParams) {
  const adminFormStore = useAdminFormsStore().getState();

  return (
    <AdminFormByIdProvider adminFormsStore={adminFormStore}>
      <AdminFormContent>
        {params.children}
      </AdminFormContent>
    </AdminFormByIdProvider>
  );
}
