"use client";

import { useAdminFormsByIdStore } from "@/ui/features/admin/forms/byid/AdminFormByIdContext";
import { useEffect } from "react";


export default function ComparePage() {
    const formByIdStore = useAdminFormsByIdStore().getState();
    const formDetail = formByIdStore.getFormDetail();


    return (
        <div>
            <p>Compare forms by ID</p>
        </div>
    );
}