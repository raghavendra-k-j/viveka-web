export default function AdminFormsList() {
    return (
        <div>
        <h1>Admin Forms List</h1>
        <p>List of forms</p>
        </div>
    );
}