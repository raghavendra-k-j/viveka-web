"use client";

import { AdminFormsProvider } from "@/ui/features/admin/forms/AdminFormsContext";

type AdminFormsLayoutParams = {
    children: React.ReactNode;
}


export default function AdminFormsLayout(params: AdminFormsLayoutParams) {
    return (<>
        <AdminFormsProvider>
            {params.children}
        </AdminFormsProvider>
    </>);
}