"use client"; // <--- Add this directive at the very top

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useGlobalStore } from '@/stores/globalStore'; // Adjust path if needed
import { useEffect, useState } from 'react';

export default function Header() {
  // Get user name and theme from the global store
  const userName = useGlobalStore((state) => state.user?.name);
  const theme = useGlobalStore((state) => state.theme);

  // Get the current pathname using the usePathname hook
  const pathname = usePathname(); // <--- Use usePathname()

  // State for displaying current date/time (remains the same)
  const [currentDateTime, setCurrentDateTime] = useState('');

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentDateTime(
        now.toLocaleDateString('en-US', { // Changed formatting slightly for broader compatibility
          weekday: 'short', year: 'numeric', month: 'short',
          day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
        })
      );
    };
    updateDateTime();
    const intervalId = setInterval(updateDateTime, 60000);
    return () => clearInterval(intervalId);
  }, []);

  // Helper function to determine active link style
  const getLinkClassName = (path: string): string => {
    const baseClasses = "px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150";
    const activeClasses = "bg-sky-600 text-white";
    const inactiveClasses = "text-gray-700 hover:bg-sky-100"; // Adjust dark later

    // Compare against the pathname from usePathname()
    return `${baseClasses} ${pathname === path ? activeClasses : inactiveClasses}`; // <--- Use pathname variable
  };

  return (
    <header className="bg-white shadow-md p-4"> {/* Add dark mode classes later */}
      <div className="container mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Left side: User Name */}
        <div className="text-lg font-semibold text-gray-800">
          Welcome, {userName || 'Guest'}!
        </div>

        {/* Middle: Navigation Tabs */}
        <nav className="flex space-x-2 sm:space-x-4">
          <Link href="/home/todos" className={getLinkClassName('/home/todos')}>
            Todos
          </Link>
          <Link href="/home/habits" className={getLinkClassName('/home/habits')}>
            Habits
          </Link>
          <Link href="/home/profile" className={getLinkClassName('/home/profile')}>
            Profile
          </Link>
        </nav>

        {/* Right side: Date and Time */}
        <div className="text-sm text-gray-600">
          {currentDateTime || 'Loading time...'}
        </div>
      </div>
    </header>
  );
}