"use client";

import React, { useState } from 'react';
import { Todo, useTodosStore } from '@/stores/todosStore'; // Adjust path if needed
import { useGlobalStore } from '@/stores/globalStore'; // Adjust path if needed

export default function TodoList() {

  console.debug('Rendering TodoList component...');
  
  // --- State from Stores ---
  // Select the todos array. Component re-renders only if 'todos' changes.
  const todos = useTodosStore((state) => state.todos);
  // Get actions directly using getState() inside handlers - avoids re-render if actions definition changes (rare)
  const { addTodo} = useTodosStore.getState();

  // Select the user's name for the 'createdBy' field.
  const userName = useGlobalStore((state) => state.user?.name);

  // --- Local State for Input ---
  const [newTodoText, setNewTodoText] = useState('');

  // --- Event Handlers ---
  const handleAddTodo = (e: React.FormEvent) => {
    e.preventDefault(); // Prevent page reload if using a form element
    const trimmedText = newTodoText.trim();
    if (trimmedText) {
      // Pass the text and the current user's name (or fallback)
      addTodo(trimmedText, userName || 'Unknown');
      setNewTodoText(''); // Clear the input field
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-800">My Todos</h2>

      {/* --- Add Todo Form --- */}
      <form onSubmit={handleAddTodo} className="flex space-x-2">
        <input
          type="text"
          value={newTodoText}
          onChange={(e) => setNewTodoText(e.target.value)}
          placeholder="Add a new todo..."
          className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-1"
        >
          Add
        </button>
      </form>

      {/* --- Todo List --- */}
      {todos.length === 0 ? (
        <p className="text-gray-500">No todos yet! Add one above.</p>
      ) : (
        TodoListView()
      )}
    </div>
  );
}

function TodoListView(): React.ReactNode {
  console.debug('Rendering TodoListView component...');

  const { todos, toggleTodo, removeTodo } = useTodosStore.getState();

  return <ul className="space-y-3">
    {todos.map((todo) => (
      <li
        key={todo.id}
        className="flex items-center justify-between p-3 bg-white rounded-md shadow transition-colors duration-150 hover:bg-gray-50"
      >
        <div className="flex items-center space-x-3">
          <input
            type="checkbox"
            checked={todo.completed}
            onChange={() => toggleTodo(todo.id)}
            className="h-5 w-5 text-sky-600 border-gray-300 rounded focus:ring-sky-500 cursor-pointer" />
          <span
            className={`text-gray-800 ${todo.completed ? 'line-through text-gray-400' : ''}`}
          >
            {todo.text}
          </span>
        </div>
        <div className='flex items-center space-x-3'>
          <span className='text-xs text-gray-400 italic'>
            (By: {todo.createdBy || 'N/A'})
          </span>
          <button
            onClick={() => removeTodo(todo.id)}
            aria-label={`Remove todo ${todo.text}`}
            className="px-2 py-1 text-sm text-red-600 hover:text-red-800 focus:outline-none"
          >
            &times; {/* Multiplication sign for 'X' */}
          </button>
        </div>

      </li>
    ))}
  </ul>;
}
