"use client";

import TodoList from './TodoList';

export default function TodosPage() {
    return (
        <>
            <TodoList />
        </>
    );
}