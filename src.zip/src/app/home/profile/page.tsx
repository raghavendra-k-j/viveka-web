"use client"; // Essential for using hooks and event handlers

import React, { useState, useEffect } from 'react';
import { useGlobalStore } from '@/stores/globalStore'; // Adjust path if needed
import { useRouter } from 'next/navigation'; // For potential redirect

export default function ProfilePage() {
  // --- State from Store ---
  // Select user data and the update action
  const user = useGlobalStore((state) => state.user);
  const { updateUserProfile } = useGlobalStore.getState(); // Get action reference

  // --- Router for Navigation ---
  const router = useRouter();

  // --- Local State for Form Inputs ---
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(true); // To handle initial load
  const [message, setMessage] = useState<string | null>(null); // For feedback

  // --- Effect to Sync Form with Store Data ---
  useEffect(() => {
    // Check if user state has been determined (is not undefined)
    // Zustand initializes state synchronously, so we mainly check for null/object
    if (user === undefined) {
      // Still loading state from potential persistence etc. (less common with default Zustand)
      setIsLoading(true);
    } else if (user) {
      // User is logged in, populate form
      setName(user.name);
      setEmail(user.email);
      setIsLoading(false);
    } else {
      // User is explicitly null (logged out)
      setIsLoading(false);
      // Optional: Redirect to login or show message if user must be logged in
      // alert("You need to be logged in to view this page.");
      // router.push('/login'); // Example redirect (if you have a login page)
      console.log("User is not logged in. Redirect or show login message.");
    }
  }, [user]); // Rerun when the user object changes in the store

  // --- Form Submission Handler ---
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null); // Clear previous messages

    if (!user) {
         setMessage("Cannot update profile. User not logged in.");
         return;
    }

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName || !trimmedEmail) {
        setMessage("Name and Email cannot be empty.");
        return;
    }

    try {
      // Call the action from the store
      updateUserProfile({ name: trimmedName, email: trimmedEmail });
      setMessage("Profile updated successfully!");
      // Optional: Redirect after a short delay
      // setTimeout(() => router.push('/home/todos'), 1500);
    } catch (error) {
       console.error("Failed to update profile:", error);
       setMessage("Failed to update profile. Please try again.");
    }
  };

  // --- Render Logic ---
  if (isLoading) {
    // Optional: Show a proper loading spinner component
    return <div className="container mx-auto p-6 text-center">Loading profile...</div>;
  }

  if (!user) {
    // Render this if user is confirmed to be logged out
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-2xl font-semibold mb-4">Profile</h1>
        <p className="text-red-600">Please log in to view or edit your profile.</p>
        {/* Optional: Add a login button/link here */}
      </div>
    );
  }

  // Render the profile form if user is logged in
  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8 max-w-md">
      <h1 className="text-2xl font-semibold mb-6 text-gray-800">Edit Profile</h1>
      <form onSubmit={handleUpdateProfile} className="space-y-4 p-6 bg-white rounded-lg shadow-md">
        <div>
          <label htmlFor="profile-name" className="block text-sm font-medium text-gray-700 mb-1">
            Name
          </label>
          <input
            type="text"
            id="profile-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>
        <div>
          <label htmlFor="profile-email" className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <input
            type="email"
            id="profile-email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
             className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>

        {message && (
          <p className={`text-sm ${message.includes('successfully') ? 'text-green-600' : 'text-red-600'}`}>
            {message}
          </p>
        )}

        <button
          type="submit"
          className="w-full px-4 py-2 bg-sky-600 text-white font-semibold rounded-md shadow hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2"
        >
          Update Profile
        </button>
      </form>
    </div>
  );
}