"use client";

import React, { useState } from 'react';
import { useHabitsStore } from '@/stores/habitsStore'; // Adjust path if needed
import { useGlobalStore } from '@/stores/globalStore'; // Adjust path if needed

export default function HabitList() {
    // --- State from Stores ---
    const habits = useHabitsStore((state) => state.habits);
    const { addHabit, removeHabit } = useHabitsStore.getState();
    const userName = useGlobalStore((state) => state.user?.name);

    // --- Local State for Inputs ---
    const [newHabitName, setNewHabitName] = useState('');
    const [newHabitFrequency, setNewHabitFrequency] = useState(''); // e.g., 'Daily', 'Weekly'

    // --- Event Handlers ---
    const handleAddHabit = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedName = newHabitName.trim();
        const trimmedFrequency = newHabitFrequency.trim();

        if (trimmedName && trimmedFrequency) {
            addHabit(trimmedName, trimmedFrequency, userName || 'Unknown');
            setNewHabitName('');
            setNewHabitFrequency('');
        } else {
            // Basic feedback, could use a proper notification system
            alert('Please provide both a name and a frequency for the habit.');
        }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800">My Habits</h2>

            {/* --- Add Habit Form --- */}
            <form onSubmit={handleAddHabit} className="space-y-3 p-4 border rounded-md bg-white shadow-sm">
                <h3 className="text-lg font-medium text-gray-700">Add New Habit</h3>
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                    <input
                        type="text"
                        value={newHabitName}
                        onChange={(e) => setNewHabitName(e.target.value)}
                        placeholder="Habit name (e.g., Exercise)"
                        className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required // Added basic required validation
                    />
                    <input
                        type="text"
                        value={newHabitFrequency}
                        onChange={(e) => setNewHabitFrequency(e.target.value)}
                        placeholder="Frequency (e.g., Daily, Weekly)"
                        className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
                        required // Added basic required validation
                    />
                </div>
                <button
                    type="submit"
                    className="w-full sm:w-auto px-4 py-2 bg-sky-600 text-white rounded-md hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-1"
                >
                    Add Habit
                </button>
            </form>

            {/* --- Habit List --- */}
            {habits.length === 0 ? (
                <p className="text-gray-500">No habits tracked yet. Add one above.</p>
            ) : (
                <ul className="space-y-3">
                    {habits.map((habit) => (
                        <li
                            key={habit.id}
                            className="flex items-center justify-between p-3 bg-white rounded-md shadow transition-colors duration-150 hover:bg-gray-50"
                        >
                            <div className="flex flex-col">
                                <span className="font-medium text-gray-800">{habit.name}</span>
                                <span className="text-sm text-gray-500">{habit.frequency}</span>
                            </div>
                            <div className='flex items-center space-x-3'>
                                <span className='text-xs text-gray-400 italic'>
                                    (By: {habit.createdBy || 'N/A'})
                                </span>
                                <button
                                    onClick={() => removeHabit(habit.id)}
                                    aria-label={`Remove habit ${habit.name}`}
                                    className="px-2 py-1 text-sm text-red-600 hover:text-red-800 focus:outline-none"
                                >
                                    &times; {/* Multiplication sign for 'X' */}
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}