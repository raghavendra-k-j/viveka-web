import HabitList from './HabitList';

export default function HabitsPage() {
    return (
        <>
            <HabitList />
        </>
    );
}