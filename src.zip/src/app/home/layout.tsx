"use client";

import React from 'react';
import Header from './Header';
import { useGlobalStore } from '@/stores/globalStore'; // Adjust path if needed

interface HomeLayoutProps {
  children: React.ReactNode;
}

export default function HomeLayout({ children }: HomeLayoutProps) {
  // Access theme to potentially apply dark mode classes later
  const theme = useGlobalStore((state) => state.theme);
  // Example: const darkMode = theme.mode === 'dark';

  return (
    // Example: Add 'dark' class here if darkMode is true for Tailwind dark mode
    <div className={`min-h-screen flex flex-col bg-gray-50`}> {/* Add dark mode classes later */}
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
        {children} {/* Page-specific content will be rendered here */}
      </main>
      {/* You could add a footer here as well */}
    </div>
  );
}