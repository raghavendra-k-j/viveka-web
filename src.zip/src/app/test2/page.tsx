// src/app/mobx-nested-todo/page.tsx

"use client"; 

import React, { useState } from 'react';
import { makeAutoObservable, computed } from 'mobx'; // action is often inferred by makeAutoObservable for methods
import { observer } from 'mobx-react-lite';

// --- Model ---

class Todo {
    id = Math.random();
    title: string = "";
    finished: boolean = false;
    subTodos: Todo[] = []; // Array to hold nested Todos

    constructor(title: string) {
        // makeAutoObservable handles properties, getters (computed), and methods (actions)
        makeAutoObservable(this, {
            // Optional: fine-tune if needed, e.g., { id: false } if id shouldn't be observable
        });
        this.title = title;
    }

    // Action (inferred by makeAutoObservable)
    toggle() {
        this.finished = !this.finished;
        console.log(`Todo "${this.title}" toggled to: ${this.finished}`);
    }

    // Action (inferred by makeAutoObservable)
    addSubTodo(title: string) {
        if (title.trim()) {
            this.subTodos.push(new Todo(title.trim()));
            console.log(`Sub-todo "${title}" added to "${this.title}"`);
        }
    }

    // Action (inferred by makeAutoObservable)
    setTitle(newTitle: string) {
        this.title = newTitle;
    }

    // Computed (inferred by makeAutoObservable because it's a getter)
    // Recursively checks if this task and ALL sub-tasks are finished
    get isFullyFinished(): boolean {
        return this.finished && this.subTodos.every(subTodo => subTodo.isFullyFinished);
    }
}

// --- Store for Top-Level Todos ---

class TodoListStore {
    todos: Todo[] = [];

    constructor(initialTodos: Todo[]) {
        makeAutoObservable(this);
        this.todos = initialTodos;
    }

    // Computed: Counts only top-level unfinished todos for simplicity here
    get unfinishedTodoCount(): number {
        return this.todos.filter(todo => !todo.finished).length;
    }
     // Computed: Counts ALL unfinished todos recursively (example)
     get totalUnfinishedRecursiveCount(): number {
        let count = 0;
        const countUnfinished = (todoList: Todo[]) => {
            for (const todo of todoList) {
                if (!todo.finished) {
                    count++;
                }
                countUnfinished(todo.subTodos);
            }
        };
        countUnfinished(this.todos);
        return count;
    }


    // Action: Adds a todo to the top-level list
    addTodo(title: string) {
        if (title.trim()) {
            this.todos.push(new Todo(title.trim()));
            console.log(`Top-level todo "${title}" added.`);
        }
    }
}


// --- View Components ---

// Renamed TodoListView to be more generic for reuse with sub-lists
const TodoItemsList: React.FC<{ todos: Todo[] }> = observer(({ todos }) => {
    console.log("Rendering TodoItemsList for", todos.length, "items");
    if (todos.length === 0) {
        return null; // Don't render empty lists
    }
    return (
        <ul className="border-l pl-3 ml-3 mt-1 space-y-1">
            {/* MobX tracks the 'todos' array passed as prop */}
            {todos.map(todo => (
                <TodoView todo={todo} key={todo.id} />
            ))}
        </ul>
    );
});


// Component to display a single Todo item - now potentially recursive
const TodoView: React.FC<{ todo: Todo }> = observer(({ todo }) => {
    const [subTodoInput, setSubTodoInput] = useState('');
    const [isAddingSubTodo, setIsAddingSubTodo] = useState(false);

    console.log(`Rendering TodoView for: "${todo.title}"`);

    const handleAddSubTodo = () => {
        todo.addSubTodo(subTodoInput);
        setSubTodoInput('');
        setIsAddingSubTodo(false);
    };

    return (
        <li className={`p-1 rounded ${todo.isFullyFinished ? 'opacity-50' : ''}`}>
            <div className="flex items-center gap-2">
                <input
                    type="checkbox"
                    checked={todo.finished}
                    onChange={() => todo.toggle()}
                    className="h-4 w-4"
                />
                {/* Simple inline edit example */}
                <input 
                   type="text" 
                   value={todo.title} 
                   onChange={(e) => todo.setTitle(e.target.value)} 
                   className={`flex-grow p-1 border-b ${todo.finished ? 'line-through' : ''} ${todo.isFullyFinished ? 'border-transparent bg-transparent' : 'border-gray-300'}`}
                   readOnly={todo.isFullyFinished} // Basic read-only if fully finished
                />
                 <button 
                    onClick={() => setIsAddingSubTodo(!isAddingSubTodo)} 
                    className="text-xs px-1 py-0.5 bg-green-100 hover:bg-green-200 rounded"
                    title="Add sub-task"
                 >
                     {isAddingSubTodo ? 'Cancel' : '+'} Sub
                 </button>
            </div>
            {/* Render input form for adding sub-task */}
            {isAddingSubTodo && (
                 <div className="ml-6 mt-1 flex gap-1">
                     <input
                        type="text"
                        value={subTodoInput}
                        onChange={(e) => setSubTodoInput(e.target.value)}
                        placeholder="New sub-task"
                        className="flex-grow p-1 border rounded text-sm"
                        autoFocus
                     />
                     <button 
                        onClick={handleAddSubTodo} 
                        className="text-xs px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
                        disabled={!subTodoInput.trim()}
                    >
                        Add
                    </button>
                 </div>
            )}

            {/* Recursively render sub-todos */}
            {/* MobX tracks todo.subTodos array */}
            <TodoItemsList todos={todo.subTodos} />
        </li>
    );
});


// Component for the input form to add new TOP-LEVEL Todos
const AddTodoForm: React.FC<{ todoListStore: TodoListStore }> = ({ todoListStore }) => {
    const [inputValue, setInputValue] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        todoListStore.addTodo(inputValue); // Use store's action
        setInputValue('');
    };

    console.log("Rendering AddTodoForm");

    return (
        <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
            <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Add new top-level task..."
                className="flex-grow p-2 border rounded"
            />
            <button type="submit" className="px-4 py-2 bg-indigo-500 text-white rounded hover:bg-indigo-600">
                Add Task
            </button>
        </form>
    );
}

// --- Main Page Component ---

export default function MobxNestedTodoPage() {
    console.log("Rendering MobxNestedTodoPage");

    // Initialize the main store instance once
    const [todoListStore] = useState(() => new TodoListStore([
        new Todo("Chapter 1: Learn MobX Basics"),
        new Todo("Chapter 2: Build Nested App"),
    ]));
    // Add some initial sub-tasks for demonstration
    useState(() => {
         if (todoListStore.todos.length > 0) {
              todoListStore.todos[0].addSubTodo("Read 'The Gist'");
              todoListStore.todos[0].addSubTodo("Try examples");
         }
          if (todoListStore.todos.length > 1) {
              todoListStore.todos[1].addSubTodo("Define Models");
              todoListStore.todos[1].addSubTodo("Create Views");
              if (todoListStore.todos[1].subTodos.length > 0) {
                   todoListStore.todos[1].subTodos[0].addSubTodo("Make them observable");
              }
          }
    });


    return (
        <div className="p-6 max-w-2xl mx-auto font-sans">
            <h1 className="text-3xl font-bold mb-6 text-center text-indigo-700">MobX Nested Todo List</h1>

            <AddTodoForm todoListStore={todoListStore} />

            <div className="border rounded p-4">
                <h2 className="text-xl font-semibold mb-2">Tasks</h2>
                {/* Render the top-level list */}
                <TodoItemsList todos={todoListStore.todos} />
                <p className="mt-4 text-right font-semibold">
                   Top-Level Unfinished: {todoListStore.unfinishedTodoCount} / Total Recursive Unfinished: {todoListStore.totalUnfinishedRecursiveCount}
                </p>
            </div>

             {/* Explanation Box */}
             <div className="mt-6 p-4 border rounded bg-gray-50 text-sm">
                <h3 className="font-semibold mb-2">Nested MobX Features:</h3>
                <ul className="list-disc list-inside space-y-1">
                    <li>The `Todo` class now has an observable `subTodos` array.</li>
                    <li>`makeAutoObservable` automatically handles nested observability. Changes deep within the structure (e.g., toggling a sub-sub-task) are tracked.</li>
                    <li>The `TodoView` component renders recursively using `TodoItemsList`.</li>
                    <li>Actions like `toggle` or `addSubTodo` modify the observable state directly.</li>
                    <li>`observer` ensures only the necessary components/sub-trees update when state changes, even for nested data.</li>
                     <li>The `isFullyFinished` computed property demonstrates deriving state recursively.</li>
                </ul>
            </div>
        </div>
    );
}