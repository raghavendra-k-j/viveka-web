// src/app/test/page.tsx
"use client"; // Directive for Next.js App Router

import React, { createContext, useContext, useState, ReactNode } from "react";

// --- Type Definitions ---

// Specific state and actions for an Assessment form
interface AssessmentDetailState {
  totalQuestions: number;
  totalMarks: number;
  passingMarks: number; // Specific to Assessment
}
interface AssessmentDetailActions {
  addQuestion: () => void;
  resetForm: () => void;
  setPassingMarks: (marks: number) => void; // Specific to Assessment
}
type AssessmentDetailReturn = AssessmentDetailState & AssessmentDetailActions;

// Specific state and actions for a Survey form
interface SurveyDetailState {
  totalQuestions: number;
  allowAnonymous: boolean; // Specific to Survey
}
interface SurveyDetailActions {
  addQuestion: () => void;
  resetForm: () => void;
  setAllowAnonymous: (allow: boolean) => void; // Specific to Survey
}
type SurveyDetailReturn = SurveyDetailState & SurveyDetailActions;

// Union type for any possible form detail controller return value
type FormDetailReturn = AssessmentDetailReturn | SurveyDetailReturn;

// Type for the main layout controller's return value
interface FormLayoutControllerReturn {
  tabIndex: number;
  setTabIndex: (index: number) => void;
  formDetail: FormDetailReturn; // Holds either Assessment or Survey details
}

// Type for the context value
type FormLayoutContextType = FormLayoutControllerReturn | null;

// --- 1. Specific Sub-controllers (View Models) ---

// Hook for Assessment form details
function useAssessmentFormDetailVm(): AssessmentDetailReturn {
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [totalMarks, setTotalMarks] = useState(0);
  const [passingMarks, setPassingMarks] = useState(50); // Default passing marks

  const addQuestion = () => {
    setTotalQuestions((q) => q + 1);
    setTotalMarks((m) => m + 5); // Each question worth 5 marks
  };

  const resetForm = () => {
    setTotalQuestions(0);
    setTotalMarks(0);
    setPassingMarks(50); // Reset passing marks too
  };

  return {
    totalQuestions,
    totalMarks,
    passingMarks,
    addQuestion,
    resetForm,
    setPassingMarks,
  };
}

// Hook for Survey form details
function useSurveyFormDetailVm(): SurveyDetailReturn {
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [allowAnonymous, setAllowAnonymous] = useState(true); // Default allow anonymous

  const addQuestion = () => {
    setTotalQuestions((q) => q + 1);
    // Surveys might not have marks
  };

  const resetForm = () => {
    setTotalQuestions(0);
    setAllowAnonymous(true);
  };

  return {
    totalQuestions,
    allowAnonymous,
    addQuestion,
    resetForm,
    setAllowAnonymous,
  };
}

// --- 2. Main controller: useFormLayoutController ---
// Now accepts a formType to determine which detail hook to use
function useFormLayoutController(
  formType: 'assessment' | 'survey'
): FormLayoutControllerReturn {
  const [tabIndex, setTabIndex] = useState(0);

  // Conditionally use the appropriate detail hook based on formType
  // Note: Hooks must be called unconditionally, so we use a pattern like this.
  // A more complex alternative might involve passing the hook itself as an argument.
  const assessmentDetail = useAssessmentFormDetailVm();
  const surveyDetail = useSurveyFormDetailVm();

  // Select the correct detail based on the type
  const formDetail = formType === 'assessment' ? assessmentDetail : surveyDetail;

  return {
    tabIndex,
    setTabIndex,
    // The type of formDetail here is correctly inferred as the union type
    formDetail,
  };
}

// --- 3. Context + Provider ---
const FormLayoutContext = createContext<FormLayoutContextType>(null);

// Provider now accepts formType and passes it to the controller hook
interface FormLayoutProviderProps {
  children: ReactNode;
  formType: 'assessment' | 'survey'; // Required prop to specify form type
}

function FormLayoutProvider({ children, formType }: FormLayoutProviderProps) {
  // Pass the formType to the controller hook
  const controller = useFormLayoutController(formType);
  return (
    <FormLayoutContext.Provider value={controller}>
      {children}
    </FormLayoutContext.Provider>
  );
}

// Custom hook to consume the context (no changes needed here)
function useFormLayoutStore(): NonNullable<FormLayoutContextType> {
  const ctx = useContext(FormLayoutContext);
  if (!ctx) {
    throw new Error("useFormLayoutStore must be used within a FormLayoutProvider");
  }
  return ctx;
}

// --- 4. UI Components ---
// Components now use type guards to handle different formDetail types

function Header() {
  const { formDetail } = useFormLayoutStore();

  // Default title
  let title = "📘 Form Builder";
  // Type guard to check if it's an Assessment
  if ('totalMarks' in formDetail) {
      title = "📘 Math Assessment";
  }
  // Type guard to check if it's a Survey
  else if ('allowAnonymous' in formDetail) {
      title = "📝 Survey";
  }

  return (
    <div className="bg-gray-100 p-4 mb-4 border-b rounded-t-md">
      <h1 className="text-2xl font-semibold">{title}</h1>
      <p className="text-sm text-gray-600">
        Total Questions: <strong>{formDetail.totalQuestions}</strong>
        {/* Use type guard to display Assessment-specific info */}
        {'totalMarks' in formDetail && (
          <> | Total Marks: <strong>{formDetail.totalMarks}</strong></>
        )}
        {/* Use type guard to display Survey-specific info */}
        {'allowAnonymous' in formDetail && (
          <> | Anonymous Allowed: <strong>{formDetail.allowAnonymous ? 'Yes' : 'No'}</strong></>
        )}
      </p>
    </div>
  );
}

// TabNavigation remains the same as it only uses tabIndex/setTabIndex
function TabNavigation() {
  const { tabIndex, setTabIndex } = useFormLayoutStore();

  return (
    <div className="flex space-x-4 mb-6">
      <button
        onClick={() => setTabIndex(0)}
        className={`px-4 py-2 rounded transition-colors duration-200 ${
          tabIndex === 0
            ? "bg-blue-500 text-white shadow-md"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }`}
      >
        Builder
      </button>
      <button
        onClick={() => setTabIndex(1)}
        className={`px-4 py-2 rounded transition-colors duration-200 ${
          tabIndex === 1
            ? "bg-blue-500 text-white shadow-md"
            : "bg-gray-200 text-gray-700 hover:bg-gray-300"
        }`}
      >
        Reports
      </button>
       {/* Example: Add a Settings Tab only for Assessments */}
       {'passingMarks' in useFormLayoutStore().formDetail && (
         <button
           onClick={() => setTabIndex(2)} // Assuming index 2 is Settings
           className={`px-4 py-2 rounded transition-colors duration-200 ${
             tabIndex === 2
               ? "bg-blue-500 text-white shadow-md"
               : "bg-gray-200 text-gray-700 hover:bg-gray-300"
           }`}
         >
           Settings
         </button>
       )}
    </div>
  );
}


function BuilderTab() {
  const { formDetail } = useFormLayoutStore();
  return (
    <div className="space-y-4 p-4 bg-white rounded-b-md shadow">
      <p className="text-lg font-medium">🛠 Add questions to your form:</p>
      <div className="flex space-x-2">
        <button
          onClick={formDetail.addQuestion} // Common action
          className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded transition-colors duration-200 shadow"
        >
          ➕ Add Question
        </button>
        <button
          onClick={formDetail.resetForm} // Common action
          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition-colors duration-200 shadow"
        >
          ♻️ Reset Form
        </button>

        {/* Example: Survey-specific setting */}
        {'allowAnonymous' in formDetail && (
            <label className="flex items-center space-x-2">
                <input
                    type="checkbox"
                    checked={formDetail.allowAnonymous}
                    onChange={(e) => formDetail.setAllowAnonymous(e.target.checked)}
                />
                <span>Allow Anonymous</span>
            </label>
        )}
      </div>
    </div>
  );
}

function ReportsTab() {
  const { formDetail } = useFormLayoutStore();
  return (
    <div className="space-y-2 p-4 bg-white rounded-b-md shadow">
      <p className="text-lg font-medium">📊 Report Overview:</p>
      <p className="text-gray-700">✅ Total Questions: {formDetail.totalQuestions}</p>
      {/* Use type guard for Assessment-specific report data */}
      {'totalMarks' in formDetail && (
        <>
            <p className="text-gray-700">✅ Total Marks: {formDetail.totalMarks}</p>
            <p className="text-gray-700">✅ Passing Marks: {formDetail.passingMarks}%</p>
        </>
      )}
      {/* Use type guard for Survey-specific report data */}
       {'allowAnonymous' in formDetail && (
        <p className="text-gray-700">
            ✅ Anonymous Submissions: {formDetail.allowAnonymous ? 'Enabled' : 'Disabled'}
        </p>
      )}
    </div>
  );
}

// Example: Settings tab only for Assessments
function SettingsTab() {
    const { formDetail } = useFormLayoutStore();

    // We can be more certain it's an Assessment here because the tab
    // is conditionally rendered, but a type guard is still safest.
    if (!('passingMarks' in formDetail)) {
        return <div>Settings only available for Assessments.</div>; // Or null
    }

    return (
        <div className="space-y-2 p-4 bg-white rounded-b-md shadow">
            <p className="text-lg font-medium">⚙️ Assessment Settings:</p>
            <label className="flex items-center space-x-2">
                <span>Passing Marks (%):</span>
                <input
                    type="number"
                    value={formDetail.passingMarks}
                    onChange={(e) => formDetail.setPassingMarks(parseInt(e.target.value, 10) || 0)}
                    className="border rounded px-2 py-1 w-20"
                    min="0"
                    max="100"
                />
            </label>
        </div>
    );
}


// --- 5. Form Layout Content Component ---
// Renders the correct UI based on the context state
function FormLayoutContent() {
    const { tabIndex, formDetail } = useFormLayoutStore();

    // Define the base tabs
    const baseTabs = [
        <BuilderTab key="builder" />,
        <ReportsTab key="reports" />,
    ];

    // Conditionally add the Settings tab for assessments
    const allTabs = 'passingMarks' in formDetail
        ? [...baseTabs, <SettingsTab key="settings" />]
        : baseTabs;

    return (
        <div className="p-6 max-w-xl mx-auto bg-gray-50 rounded-md shadow-lg">
            <Header />
            <TabNavigation />
            <div className="mt-4 border-t pt-4">
                {/* Render the selected tab */}
                {allTabs[tabIndex] ?? <div>Tab not found</div>}
            </div>
        </div>
    );
}


// --- 6. Main Page Component ---
export default function TestPage() {
  // Choose which type of form to render. This could come from props, state, URL, etc.
  const currentFormType: 'assessment' | 'survey' = 'assessment'; // Or 'survey'

  return (
    // Pass the chosen formType to the provider
    <FormLayoutProvider formType={currentFormType}>
      <FormLayoutContent />
    </FormLayoutProvider>
  );
}
