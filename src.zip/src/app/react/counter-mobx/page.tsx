"use client";
import React, { ReactNode, useState } from "react";
import { makeObservable, observable, action, computed } from "mobx";
import { observer } from "mobx-react-lite";

// ----- Timer Store -----
class TimerStore {
  seconds = 0;

  constructor() {
    makeObservable(this, {
      seconds: observable,
      increment: action,
      reset: action,
      isEven: computed,
    });
  }

  increment() {
    this.seconds++;
  }

  reset() {
    this.seconds = 0;
  }

  get isEven() {
    return this.seconds % 2 === 0;
  }
}

const timerStore = new TimerStore();

// ----- Page Component -----
export default function Page() {
  const [isTimerDialogOpen, setTimerDialogOpen] = useState(false);
  const [isNestedDialogOpen, setNestedDialogOpen] = useState(false);

  // Close all dialogs at once
  const closeAllDialogs = () => {
    setTimerDialogOpen(false);
    setNestedDialogOpen(false);
  };

  return (
    <div className="h-screen flex flex-col items-center justify-center bg-gray-100 space-y-6">
      <TimerCard store={timerStore} />

      <Button onClick={() => setTimerDialogOpen(true)}>Open Timer Dialog</Button>

      {/* Outer Dialog */}
      {isTimerDialogOpen && (
        <Dialog onClose={closeAllDialogs}>
          <TimerCard store={timerStore} />
          <Button onClick={() => setNestedDialogOpen(true)}>Open Settings</Button>
        </Dialog>
      )}

      {/* Nested Dialog */}
      {isNestedDialogOpen && (
        <Dialog onClose={closeAllDialogs}>
          <SettingsDialogContent onCloseAll={closeAllDialogs} />
        </Dialog>
      )}
    </div>
  );
}

// ----- Timer UI -----
const TimerCard = observer(({ store }: { store: TimerStore }) => {
  return (
    <div className="bg-white p-6 rounded shadow-md text-center space-y-4">
      <h1 className="text-2xl font-bold">Timer</h1>
      <div className="text-xl">Seconds: {store.seconds}</div>
      <div className="text-md text-gray-600">
        Even? {store.isEven ? "Yes" : "No"}
      </div>
      <div className="flex justify-center gap-4">
        <Button onClick={() => store.increment()}>+1</Button>
        <Button onClick={() => store.reset()}>Reset</Button>
      </div>
    </div>
  );
});

// ----- Settings Dialog (Nested) -----
function SettingsDialogContent({ onCloseAll }: { onCloseAll: () => void }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Settings</h2>
      <p>These are nested settings inside the Timer dialog.</p>
      <Button onClick={onCloseAll}>Close All Dialogs</Button>
    </div>
  );
}

// ----- Reusable Button -----
function Button({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 focus:outline-none"
    >
      {children}
    </button>
  );
}

// ----- Dialog Wrapper -----
function Dialog({ children, onClose }: { children: ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-sm w-full relative shadow-lg space-y-4">
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
        >
          ✕
        </button>
        {children}
      </div>
    </div>
  );
}
