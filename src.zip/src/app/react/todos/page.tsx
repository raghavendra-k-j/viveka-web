'use client';
import React, { useState } from 'react';
import { makeAutoObservable } from 'mobx';
import { observer } from 'mobx-react-lite';
import { v4 as uuidv4 } from 'uuid';
import clsx from 'clsx';

// ---------- TYPES ----------
type Filter = 'ALL' | 'COMPLETED' | 'PENDING';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
  important: boolean;
}

// ---------- STORE ----------
class TodosStore {
  todos = new Map<string, Todo>();
  selectedIds = new Set<string>();
  filter: Filter = 'ALL';
  search: string = '';

  constructor() {
    makeAutoObservable(this);
  }

  get filteredTodos() {
    return Array.from(this.todos.values()).filter((todo) => {
      const matchesFilter =
        this.filter === 'ALL' ||
        (this.filter === 'COMPLETED' && todo.completed) ||
        (this.filter === 'PENDING' && !todo.completed);
      const matchesSearch = todo.text.toLowerCase().includes(this.search.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }

  addTodo(text: string) {
    const id = uuidv4();
    this.todos.set(id, { id, text, completed: false, important: false });
  }

  editTodo(id: string, text: string) {
    const todo = this.todos.get(id);
    if (todo) todo.text = text;
  }

  deleteTodo(id: string) {
    this.todos.delete(id);
    this.selectedIds.delete(id);
  }

  toggleComplete(id: string) {
    const todo = this.todos.get(id);
    if (todo) todo.completed = !todo.completed;
  }

  toggleImportant(id: string) {
    const todo = this.todos.get(id);
    if (todo) todo.important = !todo.important;
  }

  toggleSelect(id: string) {
    if (this.selectedIds.has(id)) this.selectedIds.delete(id);
    else this.selectedIds.add(id);
  }

  clearSelection() {
    this.selectedIds.clear();
  }

  deleteSelected() {
    this.selectedIds.forEach((id) => this.todos.delete(id));
    this.clearSelection();
  }

  markSelected(completed: boolean) {
    this.selectedIds.forEach((id) => {
      const todo = this.todos.get(id);
      if (todo) todo.completed = completed;
    });
  }

  setFilter(filter: Filter) {
    this.filter = filter;
  }

  setSearch(search: string) {
    this.search = search;
  }
}

const todosStore = new TodosStore();

// ---------- COMPONENTS ----------
export default function TodosPage() {
  console.log('[RENDER] TodosPage');
  const [dialog, setDialog] = useState<'create' | 'edit' | null>(null);
  const [editTodo, setEditTodo] = useState<Todo | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  return (
    <div className="flex flex-col p-4 bg-gray-100 min-h-screen space-y-4">
      <Header onOpenCreate={() => setDialog('create')} />
      <TodoTable
        onEdit={(todo) => {
          setEditTodo(todo);
          setDialog('edit');
        }}
        onConfirmDelete={(id) => setDeleteConfirmId(id)}
      />
      <BulkActions />

      {dialog && (
        <TodoDialog
          mode={dialog}
          todo={editTodo}
          onClose={() => {
            setDialog(null);
            setEditTodo(null);
          }}
        />
      )}
      {deleteConfirmId && (
        <ConfirmDeleteDialog
          onConfirm={() => {
            todosStore.deleteTodo(deleteConfirmId);
            setDeleteConfirmId(null);
          }}
          onCancel={() => setDeleteConfirmId(null)}
        />
      )}
    </div>
  );
}

const Header = observer(({ onOpenCreate }: { onOpenCreate: () => void }) => {
  console.log('[RENDER] Header');
  return (
    <div className="bg-white shadow p-4 rounded space-y-2">
      <div className="text-xl font-bold">Todos</div>
      <div className="flex space-x-2 items-center">
        {(['ALL', 'COMPLETED', 'PENDING'] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => todosStore.setFilter(f)}
            className={clsx(
              'px-3 py-1 rounded border text-sm',
              todosStore.filter === f ? 'bg-blue-200' : 'bg-gray-100'
            )}
          >
            {f}
          </button>
        ))}
        <input
          placeholder="Search..."
          value={todosStore.search}
          onChange={(e) => todosStore.setSearch(e.target.value)}
          className="border px-2 py-1 rounded ml-auto"
        />
        <button onClick={onOpenCreate} className="bg-blue-600 text-white px-4 py-1 rounded">
          + New
        </button>
      </div>
    </div>
  );
});

const TodoTable = observer(({ onEdit, onConfirmDelete }: {
  onEdit: (todo: Todo) => void;
  onConfirmDelete: (id: string) => void;
}) => {
  console.log('[RENDER] TodoTable');
  const todos = todosStore.filteredTodos;

  if (todos.length === 0) return <div className="text-center text-gray-600 mt-4">No todos found.</div>;

  return (
    <table className="w-full bg-white rounded shadow">
      <thead>
        <tr className="bg-gray-200 text-left">
          <th className="p-2">Select</th>
          <th className="p-2">Todo</th>
          <th className="p-2 text-center">Actions</th>
        </tr>
      </thead>
      <tbody>
        {todos.map((todo) => (
          <TodoRow key={todo.id} todo={todo} onEdit={onEdit} onConfirmDelete={onConfirmDelete} />
        ))}
      </tbody>
    </table>
  );
});

const TodoRow = observer(({ todo, onEdit, onConfirmDelete }: {
  todo: Todo;
  onEdit: (todo: Todo) => void;
  onConfirmDelete: (id: string) => void;
}) => {
  console.log('[RENDER] TodoRow:', todo.id);
  const isSelected = todosStore.selectedIds.has(todo.id);

  return (
    <tr className="border-t">
      <td className="p-2 text-center">
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => todosStore.toggleSelect(todo.id)}
        />
      </td>
      <td className="p-2">
        <span className={clsx({ 'line-through': todo.completed, 'font-bold': todo.important })}>
          {todo.text}
        </span>
      </td>
      <td className="p-2 space-x-2 text-center">
        <button onClick={() => todosStore.toggleComplete(todo.id)} className="text-blue-600">✓</button>
        <button onClick={() => todosStore.toggleImportant(todo.id)} className="text-yellow-600">★</button>
        <button onClick={() => onEdit(todo)} className="text-green-700">Edit</button>
        <button onClick={() => onConfirmDelete(todo.id)} className="text-red-600">Delete</button>
      </td>
    </tr>
  );
});

const BulkActions = observer(() => {
  console.log('[RENDER] BulkActions');
  if (todosStore.selectedIds.size === 0) return null;

  return (
    <div className="flex space-x-4 p-2 border-t pt-4">
      <button onClick={() => todosStore.markSelected(true)} className="text-green-600">Mark Completed</button>
      <button onClick={() => todosStore.markSelected(false)} className="text-yellow-600">Mark Pending</button>
      <button onClick={() => todosStore.deleteSelected()} className="text-red-600">Delete Selected</button>
      <button onClick={() => todosStore.clearSelection()} className="text-gray-500">Clear Selection</button>
    </div>
  );
});

function TodoDialog({
  mode,
  todo,
  onClose,
}: {
  mode: 'create' | 'edit';
  todo?: Todo | null;
  onClose: () => void;
}) {
  console.log('[RENDER] TodoDialog');
  const [text, setText] = useState(todo?.text ?? '');

  const handleSubmit = () => {
    if (mode === 'create') todosStore.addTodo(text);
    else if (mode === 'edit' && todo) todosStore.editTodo(todo.id, text);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white p-4 rounded shadow-lg w-full max-w-sm space-y-4">
        <div className="text-lg font-semibold">{mode === 'create' ? 'Create New Todo' : 'Edit Todo'}</div>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="border px-3 py-2 rounded w-full"
          placeholder="Enter todo text"
        />
        <div className="flex justify-end space-x-2">
          <button onClick={onClose} className="px-4 py-1 border rounded text-gray-500">Cancel</button>
          <button
            onClick={handleSubmit}
            className="px-4 py-1 bg-blue-600 text-white rounded"
            disabled={!text.trim()}
          >
            {mode === 'create' ? 'Create' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
}

function ConfirmDeleteDialog({
  onConfirm,
  onCancel,
}: {
  onConfirm: () => void;
  onCancel: () => void;
}) {
  console.log('[RENDER] ConfirmDeleteDialog');
  return (
    <div className="fixed inset-0 bg-black-500/10 flex items-center justify-center z-50">
      <div className="bg-white p-4 rounded shadow-lg w-full max-w-sm space-y-4">
        <div className="text-lg font-semibold">Confirm Deletion</div>
        <p>Are you sure you want to delete this todo?</p>
        <div className="flex justify-end space-x-2">
          <button onClick={onCancel} className="px-4 py-1 border rounded text-gray-500">Cancel</button>
          <button onClick={onConfirm} className="px-4 py-1 bg-red-600 text-white rounded">Delete</button>
        </div>
      </div>
    </div>
  );
}
