"use client";

import { ReactNode, useState } from "react";

export default function ReactAppPage() {
    return (
        <div className="flex flex-column place-content-center h-100">
            <SimpleCounter />
            <ABitComplexCounter />
        </div>);
}

function SimpleCounter() {
    const [count, setCount] = useState(0);

    return (<>
        <div className="p-3 bg-white shadow-sm mx-auto my-5 rounded-md max-w-sm">
            <div className="text-center text-xl">{count}</div>
            <div className="flex flex-row gap-2">
                <button className="bg-blue-500 px-2 text-white rounded-sm" onClick={() => setCount(count + 1)}>Increment</button>
                <button className="bg-red-500 px-2 text-white rounded-sm" onClick={() => setCount(count - 1)}>Decrement</button>
            </div>
        </div>
    </>);
}


function ABitComplexCounter() {

    console.debug("Calling: ABitComplexCounter");

    const countState = useState(0);

    return (
        <Card>
            <CounterText count={countState[0]} />
            <ButtonsGroup countState={countState} />
        </Card>
    );
}


function Card({ children }: { children: ReactNode }) {
    return (
        <div className="bg-white shadow-sm mx-auto my-5 p-3">
            {children}
        </div>
    );
}


function CounterText({ count }: { count: number }) {
    return (
        <>Count: {count}</>
    );
}

function ButtonsGroup({ countState }: { countState: [number, React.Dispatch<React.SetStateAction<number>>] }) {
    const [count, setCount] = countState;

    return (
        <div className="flex flex-row gap-2">
            <Button onClick={() => { setCount(count + 1) }} >Increment</Button>
            <Button onClick={() => { setCount(count - 1) }}>Decrement</Button>
        </div>
    );
}

function Button({ children, onClick }: { children: ReactNode, onClick: VoidFunction }) {
    return (
        <button className="bg-slate-500 px-2 px-3 rounded-sm text-white" onClick={onClick}>{children}</button>
    );
}