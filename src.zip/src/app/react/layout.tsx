"use client";

import { usePathname, useRouter } from "next/navigation";
import { ReactNode } from "react";

export default function ReactLayoutView({ children }: { children: ReactNode }) {
    return (
        <div className="flex flex-col h-screen">
            <AppBar />
            <Content children={children} />
        </div>
    );
}


function AppBar() {
    return (
        <div className="bg-white shadow-sm border-bottom px-2 py-3 sticky top-0 z-10 flex-shrink-0">
            <div className="font-semibold">React Basics Learnings</div>
        </div>
    );
}

function Content({ children }: { children: ReactNode }) {
    return (
        <div className="flex flex-row grow overflow-hidden">
            <Sidebar />
            <MainPage children={children} />
        </div>
    );
}


function MainPage({ children }: { children: ReactNode }) {
    return (<div className="flex grow">
        {children}
    </div>);
}


function Sidebar() {
    const pathName = usePathname();


    return (
        <div className="bg-slate-50 p-3 flex flex-col gap-2 overflow-y-auto flex-shrink-0" style={{ minWidth: 320 }}>
            <SidebarItem goto={"/react/counter"} pathName={pathName}>Counter App</SidebarItem>
            <SidebarItem goto={"/react/todos"} pathName={pathName}>Todos (AI Generated Use Reducer)</SidebarItem>
        </div>
    );
}


function SidebarItem({ children, goto, pathName }: { children: ReactNode, goto: string, pathName: string }) {
    const router = useRouter();

    const isActive = pathName == goto;

    let className = "px-3 py-2 cursor-pointer rounded-sm hover:bg-blue-100 ";
    if (isActive) {
        className += "bg-blue-500 text-white hover:bg-blue-600";
    }
    else {
        className += "bg-slate-100";
    }

    return (
        <div className={className} onClick={() => router.push(goto)}>
            {children}
        </div>
    );
}