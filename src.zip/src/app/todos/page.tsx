"use client";

import { NextPage } from 'next';
import React, { memo } from 'react';
import { create } from 'zustand';

// --------------------
// Types
// --------------------
type Todo = {
  id: number;
  title: string;
  completed: boolean;
};

type TodoStore = {
  todos: Record<number, Todo>;
  toggleTodo: (id: number) => void;
  markAll: () => void;
  unmarkAll: () => void;
  moveTodo: (fromIndex: number, toIndex: number) => void; // Keep for bulk moves
  moveItem: (id: number, direction: 'up' | 'down') => void; // New function for individual item moves
  allIds: number[];
};

// --------------------
// Zustand Store
// --------------------
const useTodoStore = create<TodoStore>((set, get) => {
  // Initialize todos and allIds
  const todos: Record<number, Todo> = {};
  const allIds: number[] = [];
  for (let i = 1; i <= 10000; i++) {
    todos[i] = { id: i, title: `Todo ${i}`, completed: false };
    allIds.push(i);
  }

  return {
    todos,
    allIds,
    // Toggle the completion status of a single todo
    toggleTodo: (id: number) =>
      set((state) => ({
        todos: {
          ...state.todos,
          [id]: {
            ...state.todos[id],
            completed: !state.todos[id].completed,
          },
        },
      })),
    // Mark all todos as completed
    markAll: () =>
      set((state) => {
        const newTodos: Record<number, Todo> = {};
        for (const id of state.allIds) {
          newTodos[id] = { ...state.todos[id], completed: true };
        }
        return { todos: newTodos };
      }),
    // Unmark all todos
    unmarkAll: () =>
      set((state) => {
        const newTodos: Record<number, Todo> = {};
        for (const id of state.allIds) {
          newTodos[id] = { ...state.todos[id], completed: false };
        }
        return { todos: newTodos };
      }),
    // Move a todo from one index to another (used for bulk moves like first/last)
    moveTodo: (fromIndex, toIndex) =>
      set((state) => {
        const updatedIds = [...state.allIds];
        // Ensure indices are within bounds
        if (fromIndex < 0 || fromIndex >= updatedIds.length || toIndex < 0 || toIndex >= updatedIds.length) {
            console.error("Invalid move indices:", fromIndex, toIndex);
            return {}; // Return empty object to indicate no state change
        }
        const [movedId] = updatedIds.splice(fromIndex, 1);
        updatedIds.splice(toIndex, 0, movedId);
        return { allIds: updatedIds };
      }),
    // Move a specific todo item up or down in the list
    moveItem: (id: number, direction: 'up' | 'down') =>
      set((state) => {
        const currentIndex = state.allIds.indexOf(id);
        if (currentIndex === -1) return {}; // Item not found

        const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;

        // Check if the move is valid (within list bounds)
        if (newIndex < 0 || newIndex >= state.allIds.length) {
          return {}; // Invalid move, do nothing
        }

        const updatedIds = [...state.allIds];
        // Swap elements using splice
        const [movedItem] = updatedIds.splice(currentIndex, 1); // Remove item from current position
        updatedIds.splice(newIndex, 0, movedItem); // Insert item at new position

        return { allIds: updatedIds };
      }),
  };
});

// --------------------
// Memoized Todo Item Component
// --------------------
const TodoItem = memo(({ id, isFirst, isLast }: { id: number; isFirst: boolean; isLast: boolean }) => {
  // Get specific todo data and actions from the store
  const todo = useTodoStore((state) => state.todos[id]);
  const toggleTodo = useTodoStore((state) => state.toggleTodo);
  const moveItem = useTodoStore((state) => state.moveItem);

  // Log re-renders for performance monitoring
  console.log(`🔄 Re-rendering TodoItem ${id}`);

  return (
    <li style={{
        marginBottom: '8px',
        padding: '8px',
        border: '1px solid #eee',
        borderRadius: '4px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between', // Align items horizontally
        backgroundColor: todo.completed ? '#f0f0f0' : '#fff' // Visual feedback for completed items
     }}
    >
      {/* Todo content */}
      <label style={{ flexGrow: 1, marginRight: '10px', textDecoration: todo.completed ? 'line-through' : 'none' }}>
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => toggleTodo(id)}
          style={{ marginRight: '8px' }}
        />
        {todo.title}
        {/* Optional: Show checkmark only when completed */}
        {/* {todo.completed ? ' ✅' : ''} */}
      </label>

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: '5px' }}>
        {/* Move Up Button */}
        <button
            onClick={() => moveItem(id, 'up')}
            disabled={isFirst} // Disable if it's the first item
            style={{ padding: '4px 8px', cursor: isFirst ? 'not-allowed' : 'pointer' }}
            aria-label={`Move ${todo.title} up`}
        >
            ⬆️
        </button>
        {/* Move Down Button */}
        <button
            onClick={() => moveItem(id, 'down')}
            disabled={isLast} // Disable if it's the last item
            style={{ padding: '4px 8px', cursor: isLast ? 'not-allowed' : 'pointer' }}
            aria-label={`Move ${todo.title} down`}
        >
            ⬇️
        </button>
      </div>
    </li>
  );
});
TodoItem.displayName = 'TodoItem'; // Set display name for debugging

// --------------------
// Total Completed Todos Component
// --------------------
const TotalCompleted = memo(() => {
  // Select only the completed count to optimize re-renders
  const completedCount = useTodoStore((state) =>
    // More efficient calculation: directly access allIds and check todos object
    state.allIds.reduce((count, id) => count + (state.todos[id]?.completed ? 1 : 0), 0)
    // Previous less efficient way: Object.values(state.todos).filter((todo) => todo.completed).length
  );

  // Log re-renders for performance monitoring
  console.log('🔄 Re-rendering TotalCompleted');

  return <p>✅ Total Completed Todos: {completedCount}</p>;
});
TotalCompleted.displayName = 'TotalCompleted'; // Set display name for debugging

// --------------------
// Main Page Component
// --------------------
const HomePage: NextPage = () => {
  // Get necessary state and actions from the store
  const allIds = useTodoStore((state) => state.allIds);
  const toggleTodo = useTodoStore((state) => state.toggleTodo); // Keep for random toggle
  const markAll = useTodoStore((state) => state.markAll);
  const unmarkAll = useTodoStore((state) => state.unmarkAll);
  const moveTodo = useTodoStore((state) => state.moveTodo); // Keep for first/last moves

  // Function to toggle a random todo's completion status
  const toggleRandomTodo = () => {
    if (allIds.length === 0) return; // Handle empty list case
    const randomId = allIds[Math.floor(Math.random() * allIds.length)];
    toggleTodo(randomId);
  };

  // Function to move the first todo to the last position
  const moveFirstToLast = () => {
    if (allIds.length > 1) {
      moveTodo(0, allIds.length - 1);
    }
  };

  // Function to move the last todo to the first position
  const moveLastToFirst = () => {
    if (allIds.length > 1) {
      moveTodo(allIds.length - 1, 0);
    }
  };

  // Log re-renders for performance monitoring
  console.log('🔄 Re-rendering HomePage');

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Zustand Todo (O(1) Updates + Memoized + Move)</h1>
      <p>Total Todos: {allIds.length}</p>

      {/* Display the total completed count */}
      <TotalCompleted />

      {/* Action buttons container */}
      <div style={{ margin: '16px 0', display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
        <button onClick={toggleRandomTodo}>
          🔁 Toggle Random
        </button>
        <button onClick={markAll}>
          ✅ Mark All
        </button>
        <button onClick={unmarkAll}>
          ❌ Unmark All
        </button>
        <button onClick={moveFirstToLast} disabled={allIds.length <= 1}>
          🔽 Move First to Last
        </button>
        <button onClick={moveLastToFirst} disabled={allIds.length <= 1}>
          🔼 Move Last to First
        </button>
      </div>

      {/* Todo list */}
      <ul style={{ listStyle: 'none', padding: 0, marginTop: '20px' }}>
        {allIds.map((id, index) => (
          <TodoItem
            key={id} // Essential for React list reconciliation
            id={id}
            isFirst={index === 0} // Pass whether it's the first item
            isLast={index === allIds.length - 1} // Pass whether it's the last item
          />
        ))}
      </ul>
    </div>
  );
};

// Export the main component
export default HomePage;
