import { AppException } from "@/core/exceptions/AppException";
import { ResEither } from "@/core/utils/ResEither";
import AdminApiClient from "@/data/sources/AdminApiClient";
import { ApiException } from "@/domain/exceptions/ApiException";
import { AdminFormDetail } from "@/domain/models/admin/forms/AdminFormDetail";

type AdminFormsRepoParams = {
    adminApiClient: AdminApiClient;
};

class AdminFormsRepo {
    private adminApiClient: AdminApiClient;

    constructor(params: AdminFormsRepoParams) {
        this.adminApiClient = params.adminApiClient;
    }

    async getAdminFormDetailByPermalink(permalink: string): Promise<ResEither<ApiException, AdminFormDetail>> {
        try {
            const response = await this.adminApiClient.getAxios().get(`/api/v1/admin/forms/${permalink}`);
            const data = AdminFormDetail.fromJson(response.data);
            return ResEither.success(data);
        }
        catch (e) {
            const error = ApiException.fromApiError(e);
            return ResEither.failure(error);
        }
    }

}

export default AdminFormsRepo;
