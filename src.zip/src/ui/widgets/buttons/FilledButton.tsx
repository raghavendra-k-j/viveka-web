import { ReactNode } from "react";

class FilledButtonTheme {
    textColor: string;

    constructor({ textColor }: { textColor: string }) {
        this.textColor = textColor;
    }

    static primary = new FilledButtonTheme({ textColor: "#FFFFFF" });


}


function FilledButton({ children, theme }: { children: ReactNode, theme: FilledButtonTheme }) {

    return (
        <button>{children}</button>
    );
}