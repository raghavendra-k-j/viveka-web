const path = require('path');

module.exports = {
  source: [path.resolve(__dirname, './tokens.json')],
  platforms: {
    css: {
      transformGroup: 'css',
      buildPath: path.resolve(__dirname, './out/') + '/',
      files: [{
        destination: 'css.css',
        format: 'css/variables'
      }]
    },
    js: {
      transformGroup: 'js',
      buildPath: path.resolve(__dirname, './out/') + '/',
      files: [{
        destination: 'js.js',
        format: 'javascript/es6'
      }]
    }
  }
};
