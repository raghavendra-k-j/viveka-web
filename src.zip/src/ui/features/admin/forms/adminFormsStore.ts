import AdminFormsRepo from "@/data/repo/admin/AdminFormsRepo";
import AdminApiClient from "@/data/sources/AdminApiClient";
import AdminFormsService from "@/domain/services/admin/AdminFormsService";
import { createStore } from "zustand/vanilla";

export interface AdminFormsStore {
    service: AdminFormsService;
}

export const createAdminFormsStore = () => {
    const adminFormsService = new AdminFormsService({ adminFormsRepo: new AdminFormsRepo({ adminApiClient: AdminApiClient.getInstance() }) });

    return createStore<AdminFormsStore>(() => ({
        service: adminFormsService,
    }));
};
