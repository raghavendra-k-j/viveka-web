import { createContext, useContext, useRef } from 'react';
import { StoreApi } from 'zustand';
import { AdminFormsStore, createAdminFormsStore } from './adminFormsStore';

const AdminFormsContext = createContext<StoreApi<AdminFormsStore> | null>(null);

type AdminFormsProviderParams = {
    children: React.ReactNode;
}


export const AdminFormsProvider = (params: AdminFormsProviderParams) => {
    const storeRef = useRef<StoreApi<AdminFormsStore> | null>(null);

    if (!storeRef.current) {
        storeRef.current = createAdminFormsStore();
    }

    return (
        <AdminFormsContext.Provider value={storeRef.current}>
            {params.children}
        </AdminFormsContext.Provider>
    );
}


export const useAdminFormsStore = () => {
    const store = useContext(AdminFormsContext);
    if (!store) throw new Error('useAdminFormsStore must be used within <AdminFormsProvider>');
    return store;
};
