import { AdminFormDetail } from "@/domain/models/admin/forms/AdminFormDetail";
import { DataState } from "@/ui/utils/datastate";
import { AdminFormsStore } from "../adminFormsStore";
import { AppException } from "@/core/exceptions/AppException";
import { createStore } from "zustand";


export interface AdminFormByIdStore {
    adminFormStore: AdminFormsStore;
    formDetailState: DataState<AdminFormDetail>;
    getFormDetail(): AdminFormDetail;
    loadFormDetail: (permalink: string) => Promise<void>;
}


export const createAdminFormByIdStore = (adminFormStore: AdminFormsStore) => {

    return createStore<AdminFormByIdStore>((set, get) => ({
        adminFormStore: adminFormStore,
        formDetailState: DataState.initial<AdminFormDetail>(),
        getFormDetail: () => get().formDetailState.data!,
        loadFormDetail: async (permalink: string) => {
            console.debug("Loading form detail for permalink: ", permalink);
            set({ formDetailState: DataState.loading<AdminFormDetail>() });
            try {
                const formDetail = (await adminFormStore.service.getAdminFormDetailByPermalink(permalink)).getOrThrow();
                console.debug("Finished loading form detail for permalink: ", permalink);
                console.debug("Form detail state: ", get().formDetailState);
                set({ formDetailState: DataState.success<AdminFormDetail>(formDetail) });
            }
            catch (error) {
                const appException = AppException.fromAny(error);
                set({ formDetailState: DataState.error<AdminFormDetail>({ error: appException }) });
                console.error("Error loading form detail: ", appException);
            }
        }
    }));
}