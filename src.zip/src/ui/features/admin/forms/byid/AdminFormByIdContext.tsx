import { createContext, useContext, useRef } from 'react';
import { StoreApi } from 'zustand';
import { AdminFormByIdStore, createAdminFormByIdStore } from './adminFormsByIdStore';
import { AdminFormsStore } from '../adminFormsStore';

const AdminFormByIdContext = createContext<StoreApi<AdminFormByIdStore> | null>(null);

type AdminFormsProviderParams = {
    adminFormsStore: AdminFormsStore;
    children: React.ReactNode;
}


export const AdminFormByIdProvider = (params: AdminFormsProviderParams) => {
    const storeRef = useRef<StoreApi<AdminFormByIdStore> | null>(null);

    if (!storeRef.current) {
        storeRef.current = createAdminFormByIdStore(params.adminFormsStore);
    }

    return (
        <AdminFormByIdContext.Provider value={storeRef.current} >
            {params.children}
        </AdminFormByIdContext.Provider>
    );
}



export const useAdminFormsByIdStore = <T,>(selector: (state: AdminFormByIdStore) => T): T => {
    const store = useContext(AdminFormByIdContext);
    if (!store) throw new Error("useAdminFormsByIdStore must be used within <AdminFormByIdProvider>");
    return selector(store.getState());
};

