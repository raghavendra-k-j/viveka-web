import { AdminFormByIdLayoutParams } from "@/app/admin/forms/[permalink]/layout";
import { useAdminFormsStore } from "../AdminFormsContext";


export default function AdminFormByIdLayout(params: AdminFormByIdLayoutParams) {
    const adminFormsStore = useAdminFormsStore();



    return (<div>
        {params.children}
        <div>{adminFormsStore.getState().service.toString()}</div>
    </div>);
}