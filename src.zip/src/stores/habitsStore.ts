import { create } from 'zustand';

// --- Interfaces ---
interface Habit {
    id: string;
    name: string;
    frequency: string;
    createdBy: string | null;
}

interface HabitsState {
    habits: Habit[];
    addHabit: (name: string, frequency: string, createdBy: string | null) => void;
    removeHabit: (id: string) => void;
}

// --- Store Implementation ---
export const useHabitsStore = create<HabitsState>((set) => ({
    // Initial state: start with an empty list of habits
    habits: [],

    // Action to add a new habit
    addHabit: (name, frequency, createdBy) => {
        // Basic ID generation (consider using a UUID library for production)
        const newId = Date.now().toString();
        const newHabit: Habit = {
            id: newId,
            name: name,
            frequency: frequency,
            createdBy: createdBy,
        };
        // Add the new habit to the existing array
        set((state) => ({
            habits: [...state.habits, newHabit],
        }));
    },

    // Action to remove a habit from the list
    removeHabit: (id) => {
        set((state) => ({
            habits: state.habits.filter((habit) => habit.id !== id),
        }));
    },
}));