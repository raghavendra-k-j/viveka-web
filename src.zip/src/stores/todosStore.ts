import { create } from 'zustand';

// --- Interfaces ---
export interface Todo {
    id: string;
    text: string;
    completed: boolean;
    createdBy: string | null;
}

interface TodosState {
    todos: Todo[];
    addTodo: (text: string, createdBy: string | null) => void;
    toggleTodo: (id: string) => void;
    removeTodo: (id: string) => void;
}

// --- Store Implementation ---
export const useTodosStore = create<TodosState>((set) => ({
    // Initial state: start with an empty list of todos
    todos: [],

    // Action to add a new todo
    addTodo: (text, createdBy) => {
        // Basic ID generation (consider using a UUID library for production)
        const newId = Date.now().toString();
        const newTodo: Todo = {
            id: newId,
            text: text,
            completed: false,
            createdBy: createdBy,
        };
        // Add the new todo to the existing array
        set((state) => ({
            todos: [...state.todos, newTodo],
        }));
    },

    // Action to toggle the 'completed' status of a todo
    toggleTodo: (id) => {
        set((state) => ({
            todos: state.todos.map((todo) =>
                todo.id === id ? { ...todo, completed: !todo.completed } : todo
            ),
        }));
    },

    // Action to remove a todo from the list
    removeTodo: (id) => {
        set((state) => ({
            todos: state.todos.filter((todo) => todo.id !== id),
        }));
    },
}));