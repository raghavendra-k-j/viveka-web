import { create } from "zustand";

interface User {
    name: string;
    email: string;
}

interface Theme {
    mode: 'light' | 'dark';
    sidebarExpanded: boolean;
}

interface GlobalStore {
    user: User | null;
    theme: Theme;
    setUser: (user: User | null) => void;
    clearUser: () => void;
    toggleSidebar: () => void;
    toggleThemeMode: () => void;
    updateUserProfile: (user: Partial<User>) => void;
}


export const useGlobalStore = create<GlobalStore>((set, get) => {
    return ({
        user: {
            name: 'John Doe',
            email: "john@gmail.com",
        },
        theme: {
            mode: 'light',
            sidebarExpanded: true,
        },

        setUser: (userData) => set({ user: userData }),
        clearUser: () => set({ user: null }),
        updateUserProfile: (data) => {
            const currentUser = get().user;
            if (currentUser) {
                const updatedUser = { ...currentUser, ...data };
                set({ user: updatedUser });
            }
        },
        toggleSidebar: () => {
            const currentSidebarState = get().theme.sidebarExpanded;
            set({
                theme: {
                    ...get().theme,
                    sidebarExpanded: !currentSidebarState,
                },
            });
        },

        toggleThemeMode: () => {
            const currentMode = get().theme.mode;
            const newMode = currentMode === 'light' ? 'dark' : 'light';
            set({
                theme: {
                    ...get().theme,
                    mode: newMode,
                },
            });
        },
    });
});