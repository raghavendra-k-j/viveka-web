import { AppException, AppExceptionParams } from "@/core/exceptions/AppException";

type ApiExceptionParams = AppExceptionParams & {
    statusCode?: number | null;
};

type ApiErrorResponse = {
    errorCode: string;
    message: string;
    description?: string | null;
    data?: any | null;
};


export class ApiException extends AppException {
    statusCode: number | null;

    constructor(params: ApiExceptionParams) {
        super(params);
        this.statusCode = params.statusCode ?? null;
    }

    get isForbidden(): boolean {
        return this.statusCode === 403;
    }

    get isNotFound(): boolean {
        return this.statusCode === 404;
    }

    get isUnauthorized(): boolean {
        return this.statusCode === 401;
    }

    get isServerError(): boolean {
        return this.statusCode === 500;
    }

    get isBadRequest(): boolean {
        return this.statusCode === 400;
    }

    get isConflict(): boolean {
        return this.statusCode === 409;
    }

    get isTooManyRequests(): boolean {
        return this.statusCode === 429;
    }

    get isServiceUnavailable(): boolean {
        return this.statusCode === 503;
    }

    get isGatewayTimeout(): boolean {
        return this.statusCode === 504;
    }

    toString(): string {
        return `ApiException: ${this.statusCode !== null ? this.statusCode : "No Status Code"} - ${this.message}${this.hasDesc() ? ` - ${this.description}` : ""}`;
    }


   
    static fromApiError(e: unknown) : ApiException {
        console.error("ApiException.fromApiError: ", e);
        throw Error("Not implemented yet");
    }



}
