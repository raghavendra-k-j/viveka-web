import { AppException } from "@/core/exceptions/AppException";
import { ResEither } from "@/core/utils/ResEither";
import AdminFormsRepo from "@/data/repo/admin/AdminFormsRepo";
import { AdminFormDetail } from "@/domain/models/admin/forms/AdminFormDetail";

type AdminFormServiceParams = {
    adminFormsRepo: AdminFormsRepo;
}

class AdminFormService {

    private adminFormsRepo: AdminFormsRepo;

    constructor(params: AdminFormServiceParams) {
        this.adminFormsRepo = params.adminFormsRepo;
    }

    async getAdminFormDetailByPermalink(permalink: string): Promise<ResEither<AppException, AdminFormDetail>> {
        const response = await this.adminFormsRepo.getAdminFormDetailByPermalink(permalink);
        return response;
    }

}


export default AdminFormService;
export type { AdminFormServiceParams };